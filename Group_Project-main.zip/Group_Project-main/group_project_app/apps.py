from django.apps import AppConfig


class GroupProjectAppConfig(AppConfig):
    name = 'group_project_app'
